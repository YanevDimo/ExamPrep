package glacialExpedition.models.explorers;

public class GlacierExplorer extends BaseExplorer{

    private static final int UNIT_ENERGY = 40;

    protected GlacierExplorer(String name) {
        super(name, UNIT_ENERGY);
    }
}
